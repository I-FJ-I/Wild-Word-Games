#ifndef _INTERPRETE
#define _INTERPRETE

#include <iostream>
using namespace std;

bool interprete_comandos(string comando);

#endif
